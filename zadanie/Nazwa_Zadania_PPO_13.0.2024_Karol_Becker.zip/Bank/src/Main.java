//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        User p1 = new User("Karol","Becker","01/01/2005", 100, "1234567890","Morąg", 18, "Men");
        User p2 = new User("Jan","Kowlaski","05/05/2002", 1000, "1237777890","Olsztyn", 28, "Men");
        User p3 = new User("Karol","Kowal","01/01/2000", 300, "1234567811","Gutkowo", 68, "Men");
        System.out.println("=====================================");
        p1.data();
        System.out.println("=====================================");
        p2.data();
        System.out.println("=====================================");
        p3.data();
        System.out.println("=====================================");
        currency c1 = new currency(1.0,5.07,4.01,4.32,4.59,2.69,2.98,0.55);
        c1.currencyShow();
        System.out.println("=====================================");
        currency c2 = new currency(1.0,5.1,4.11,4.36,4.89,2.80,3.0,0.60);
        c2.currencyShow();
        System.out.println("=====================================");
        currency c3 = new currency(1.0,5.0,4.0,4.40,4.50,2.80,2.90,0.50);
        c3.currencyShow();
        System.out.println("=====================================");
        transfer t1 = new transfer("Karol","Kowalski",50,"PLN","zakupy","13/02/2024","111/111/111","express");
        t1.transferInfo();
        System.out.println("=====================================");
        transfer t2 = new transfer("Karol","Becker",510,"EUR","obiad","12/02/2024","121/111/111","normal");
        t2.transferInfo();
        System.out.println("=====================================");
        transfer t3 = new transfer("Karol","Kowal",520,"PLN","zaplata","11/02/2024","111/131/141","express");
        t3.transferInfo();
    }
}