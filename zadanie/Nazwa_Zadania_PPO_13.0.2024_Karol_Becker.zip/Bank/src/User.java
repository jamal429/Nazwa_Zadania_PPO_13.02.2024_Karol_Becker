public class User {
    private  String name;
    private  String surname;
    private  String brithDate;
    private  int balance;
    private  String PESEL;
    private  String city;
    private  int age;
    private  String sex;

    public User(String name, String surname, String brithDate, int balance, String PESEL, String city, int age, String sex) {
        this.name = name;
        this.surname = surname;
        this.brithDate = brithDate;
        this.balance = balance;
        this.PESEL = PESEL;
        this.city = city;
        this.age = age;
        this.sex = sex;
    }
    /*********************************************************
     *  nazwa funkcji: data *
     *  parametry wejściowe: brak *
     *  wartość zwracana: brak *
     *  autor: Karol Becker*
     *  ****************************************************/
    public void data(){
        System.out.println(
                "Information about user:\nname:"+ this.name+ "\nsurname:"+ this.surname+ "\nbrith date:"+ this.brithDate+"\nbalance:"+ this.balance+"\nPESESL:"+ this.PESEL+"\ncity:"+ this.city+"\nage:"+ this.age+"\nsex:"+ this.sex);
    }
}
