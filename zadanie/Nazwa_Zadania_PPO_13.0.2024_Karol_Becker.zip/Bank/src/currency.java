public class currency {
    private double PLN;
    private double GBP;
    private double USD;
    private double EUR;
    private double CHF;
    private double JPY;
    private double CAD;
    private double CNY;

    public currency(double PLN, double GBP, double USD, double EUR, double CHF, double JPY, double CAD, double CNY) {
        this.PLN = PLN;
        this.GBP = GBP;
        this.USD = USD;
        this.EUR = EUR;
        this.CHF = CHF;
        this.JPY = JPY;
        this.CAD = CAD;
        this.CNY = CNY;
    }
    /*********************************************************
     *  nazwa funkcji: currencyShow *
     *  parametry wejściowe: brak *
     *  wartość zwracana: brak *
     *  autor: Karol Becker*
     *  ****************************************************/
    public void currencyShow(){
        System.out.println("PLN: "+this.PLN+"\nGPB: "+this.GBP+"\nUSD: "+this.USD+"\nEUR: "+this.EUR+"\nCHF: "+this.CHF+"\nJPY: "+this.JPY+"\nCAD: "+this.CAD+"\nCNY: "+this.CNY);
    }
}
