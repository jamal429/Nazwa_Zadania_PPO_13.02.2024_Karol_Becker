public class transfer {
    private String name;
    private String surname;
    private int ammount;
    private String currency;
    private String title;
    private String date;
    private String phoneNumber;
    private String type;

    public transfer(String name, String surname, int ammount, String currency, String title, String date, String phoneNumber, String type) {
        this.name = name;
        this.surname = surname;
        this.ammount = ammount;
        this.currency = currency;
        this.title = title;
        this.date = date;
        this.phoneNumber = phoneNumber;
        this.type = type;
    }
    /*********************************************************
     *  nazwa funkcji: transferInfo *
     *  parametry wejściowe: brak *
     *  wartość zwracana: brak *
     *  autor: Karol Becker*
     *  ****************************************************/
    public void transferInfo(){
        System.out.println("Info about that transfer: \nTo who: "+this.name+" "+this.surname+"\nAmmount: "+this.ammount+"\nTitle: "+this.title+"\ndate: "+this.date+"\nphone number: "+this.phoneNumber+"\nType: "+this.type);
    }
}
